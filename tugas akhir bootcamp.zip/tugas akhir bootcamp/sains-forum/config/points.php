<?php

return [
    'rewards' => [
        'new_reply' => 10,
        'new_thread' => 20,
    ],
];
