<h2 class="app text-xl font-bold font-face-serif leading-tight text-red-500">
    Sains forum
</h2>

<style>
    .app{
        font-family: Tahoma, sans-serif;
    }
</style>